
class ApiService {
  static const baseUrl = "http://localhost:5000";
}
