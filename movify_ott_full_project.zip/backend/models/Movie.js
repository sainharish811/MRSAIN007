
const mongoose = require("mongoose");

const MovieSchema = new mongoose.Schema({
  title: String,
  description: String,
  genre: [String],
  poster: String,
  videoUrl: String,
  premium: Boolean
});

module.exports = mongoose.model("Movie", MovieSchema);
